# WebScraping-YouTube-Data-For-Exploratory-Data-Analysis

I have build an Python Project to Scrape YouTube data using YouTube Data API. Using YouTube API, I extracted the data and then load this data into a Python Pandas DataFrame and then analyze this data. 
Finally, I had build a simple visualization from this data using the Python Seaborn library.

In the first part, I have extracted channel details of top Data Analysts/Data Scientists, such as youtube channel name, total no of subscribers, total views and total number of videos posted by each channel and then compare these channel data with each other.

We shall see who has the highest subscriber and who gets the most views and the amount of videos posted by these channels. We will be loading all of this data into a pandas dataframe and then analyze it. We will also generate some basic visualization using this data so we can easily compare these multiple channels.

In the second part, I have  build a logic to extract video details from 'Alex The Analyst' channel. I have extracted details such as video title, total views each video has got, total number of likes, and comments each video has got.

Then analyze this data by loading it into a pandas dataframe. At the end I have created some simple visualization using Seaborn python library.
